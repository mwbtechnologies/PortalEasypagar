import { Dialog } from '@angular/cdk/dialog';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HttpCommonService } from 'src/app/services/httpcommon.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-showcred',
  templateUrl: './showcred.component.html',
  styleUrls: ['./showcred.component.css']
})
export class ShowcredComponent {
CredentailsArray:any[]=[]; index:any=0;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,private dialog: MatDialog,private _commonservice: HttpCommonService,private spinnerService: NgxSpinnerService,private toastr: ToastrService,public dialogRef: MatDialogRef<ShowcredComponent>)
  {
    this.CredentailsArray = this.data.Array;
  }

  CloseTab()
{
  this.dialogRef.close({})
}

Share(Type:any) {
  this.spinnerService.show();
  var tmp=[];
  for(this.index=0;this.index<this.CredentailsArray.length;this.index++)
  {
    tmp.push({id:this.CredentailsArray[this.index].EmployeeID})
  }
  const json = {Employees:tmp,Type:Type}
    this._commonservice.ApiUsingPost("Portal/ShareCredentials",json).subscribe(data => {
      if(data.status==true)
      {
       this.spinnerService.hide();
      }
      else{
       this.toastr.warning(data.message);
       this.spinnerService.hide();
      }
      console.log(data)
     }, (error: any) => {
       this.spinnerService.hide();
     }
     ); 
}
SendWhatsapp() {
  this.spinnerService.show();
  for(this.index=0;this.index<this.CredentailsArray.length;this.index++)
    {
      var employeeid=this.CredentailsArray[this.index].EmployeeID;
      var fname=this.CredentailsArray[this.index].FirstName;
      var lname=this.CredentailsArray[this.index].LastName;
      var mobile=this.CredentailsArray[this.index].Mobile;
      var role=this.CredentailsArray[this.index].Role;
      var password=this.CredentailsArray[this.index].Password;

  const json={
    "receiver":[mobile],
    "type": "template",
    "tempName": "easystock_msg_temp",
    "msgType": "whatsapp",
    "receiverType": "individual",
    "SoftwareID": 11,
    "parameters": [
        {
            "type": "text",
            "text": fname + ""+ lname
        },
        {
            "type": "text",
            "text": "**1234"
        },
        {
            "type": "text",
            "text": role
        },
        {
            "type": "text",
            "text": mobile
        },
        {
            "type": "text",
            "text": password
        }
    ]
  }
  console.log(json);
  this._commonservice.MasterApiUsingPost("http://192.168.1.36/masterportalv2/promotions/whatsapp/sendText",json).subscribe(data => {
   console.log(data.status);    
   this.spinnerService.hide();
  }, (error: any) => {
    this.spinnerService.hide();
   
  }
  );

  this.toastr.success("Credentials shared successfully");
  this.CloseTab();
}
}
}
