import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { HttpCommonService } from "src/app/services/httpcommon.service";
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgxSpinnerService } from "ngx-spinner";
import { CommonTableComponent } from "../common-table/common-table.component";
import { ShowalertComponent } from "../create-employee/showalert/showalert.component";
import { MatDialog } from "@angular/material/dialog";
import { environment } from "src/environments/environment";

@Component({
  selector: "app-emp-salary-config",
  templateUrl: "./emp-salary-config.component.html",
  styleUrls: ["./emp-salary-config.component.css"],
})
export class EmpSalaryConfigComponent implements OnInit,AfterViewInit {
  
  @ViewChild(CommonTableComponent) commonTableChild: CommonTableComponent|any;

  BranchList: any
  DepartmentList: any
  EmployeeList:any
  SelectedBranches: any
  SelectedDepartments:any
  temparray: any
  tempdeparray:any
  AdminID: any
  UserID:any
  OrgID:any

  selectedBranch:any[]=[]
  Columns: any[]=[]

  ApiURL:any

  displayColumns:any
  displayedColumns:any
  editableColumns:any
  actionOptions:any
  topHeaders:any
  employeeLoading:any;
  
  selectedRows:any;
  
    
  branchSettings: IDropdownSettings = {}
  departmentSettings: IDropdownSettings = {}
  headerColors:any
  selectedOrganization:any[]=[]
  OrgList:any[]=[]
  orgSettings:IDropdownSettings = {}
  employeeSettings:IDropdownSettings = {}
  EmployeeListFilter:any[]=[]
  SelectedEmployees:any[]=[]
  selectedFile: File | null = null;
  constructor(private _commonservice: HttpCommonService,private globalToastService:ToastrService,private spinnerService: NgxSpinnerService,private cdr: ChangeDetectorRef,private dialog:MatDialog) {
    this.BranchList = []
    this.DepartmentList = []
    this.EmployeeList = []
    this.temparray = []
    this.tempdeparray = []
    this.actionOptions = []
    this.selectedRows = []

    this.employeeSettings = {
      singleSelection: false,
      idField: 'ID',
      textField: 'Name',
      itemsShowLimit: 1,
      allowSearchFilter: true,
    };
    this.headerColors ={
      Deductions : {text:"#ff2d2d",bg:"#fff1f1"},
      TDS : {text:"#ff2d2d",bg:"#fff1f1"},
      TotalDeduction : {text:"#ff2d2d",bg:"#fff1f1"},
      leaveDeduction : {text:"#ff2d2d",bg:"#fff1f1"},
      LoanDeduction : {text:"#ff2d2d",bg:"#fff1f1"},
      AdvanceDeduction : {text:"#ff2d2d",bg:"#fff1f1"},
      ESI : {text:"#ff2d2d",bg:"#fff1f1"},
      PF : {text:"#ff2d2d",bg:"#fff1f1"},
      PT : {text:"#ff2d2d",bg:"#fff1f1"},
      Earnings : {text:"#00a927",bg:"#daffe2"},
      HRA : {text:"#00a927",bg:"#daffe2"},
      BasicSalary : {text:"#00a927",bg:"#daffe2"},
      TA : {text:"#00a927",bg:"#daffe2"},
      DA : {text:"#00a927",bg:"#daffe2"},
      MA : {text:"#00a927",bg:"#daffe2"},
      TotalEarnings : {text:"#00a927",bg:"#daffe2"},
      Incentive : {text:"#00a927",bg:"#daffe2"},
      ShiftAmount : {text:"#00a927",bg:"#daffe2"},
      "Basic" : {text:"#00a927",bg:"#daffe2"},
      "Gross" : {text:"#00a927",bg:"#daffe2"},
    }

    
    this.topHeaders = [
      {
        id:"blank1",
        name:"",
        colspan:8
      },
      {
        id:"Earnings",
        name:"Earnings",
        colspan:6
      },
      {
        id:"Deductions",
        name:"Deductions",
        colspan:3
      }
      ,{
        id:"Leave",
        name:"Leave",
        colspan:2
      }
      ,{
        id:"blank2",
        name:"",
        colspan:2
      },
    ]

    this.branchSettings = {
      singleSelection: true,
      idField: 'Value',
      textField: 'Text',
      itemsShowLimit: 1,
      allowSearchFilter: true,
    };
    this.departmentSettings = {
      singleSelection: true,
      idField: 'Value',
      textField: 'Text',
      itemsShowLimit: 1,
      allowSearchFilter: true,
    };
    this.orgSettings = {
      singleSelection: true,
      idField: 'Value',
      textField: 'Text',
      itemsShowLimit: 1,
      allowSearchFilter: true,
    };
    this.actionOptions = [
      {
        name: "Submit Salary Configuration",
        icon: "fa fa-money",
        filter: [
          
        ],
      },
    ];
    
    this.displayColumns= {
      SelectAll: "SelectAll",
      "SLno":"Sl No",
      "Employee":"Employee Name",
      "MappedEmpId":"EmpID",
      "Branch":"Branch",
      "NoOfPresentDays":"Present",
      "Department":"Department",
      "Designation":"Designation",
      "TotalWokingDays":"Total",
      "BasicSalary":"Basic Salary",
      "HRA":"HRA",
      "TA":"TA",
      "DA":"DA",
      "MA":"MA",
      "ShiftAmount":"Shift Amount",
      "Incentive":"Incentive",
      "leaveDeduction":"Leave",
      "LoanDeduction":"Loan",
      "AdvanceDeduction":"Advance",
      "ESI":"ESI",
      "PF":"EPF",
      "PT":"PT",
      "TotalEarnings":"Earned Salary",
      "TotalDeduction":"Deduction",
      "NetSalary":"Payable",
      "Actions": "Actions",
      "PaidLeave":"Paid",
      "SickLeave":"Sick",
      // "SDmonthlydeduction":"SDMonthly Deposit", 
      // "Securitydeposit":"Security Deposit", 
      "FixedIncentive":"Monthly Incentive", 
      "IsPerDay":"Is Per Day", // Daily wages
      "TDS":"TDS",
      "Basic":"Basic",
      "Gross":"Gross",
      "EmployeeName": "Name",
    },

    this.displayedColumns= [
      "SelectAll",
      "SLno",
      "MappedEmpId",
      "EmployeeName",
      "Branch",
      "Department",
      "IsPerDay",
      "FixedIncentive",
      // "Securitydeposit",
      // "SDmonthlydeduction",
      "Gross",
      "Basic",
      "HRA",
      "DA",
      "MA",
      "TA",
      "ESI",
      "PF",
      "TDS",
      "PaidLeave",
      "SickLeave",
      "Actions",
    ]

    this.editableColumns = {
      "Gross":{
        // type:'Number',
        filters:{IsPerDay:false,ConfigIDStatus:true},
        regex:'^\\d{1,8}(\\.\\d{1,2})?$', 
        errorMessage:'Gross must be greater than 0 less than 100000000',
      },
      "HRA":{
        filters:{IsPerDay:false},
        regex:'^\\d{1,6}(\.\d{1,2})?$', 
        errorMessage:'HRA must be greater than equal to 0 and less than 1000000',
      },
      "DA":{
        filters:{IsPerDay:false},
        regex:'^\\d{1,6}(\\.\\d{1,2})?$', 
        errorMessage:'DA must be greater than equal to 0 and less than 1000000',
      },
      "MA":{
        filters:{IsPerDay:false},
        regex:'^\\d{1,5}(\\.\\d{1,2})?$', 
        errorMessage:'MA must be greater than equal to 0 and less than 100000',
      },
      "TA":{
        filters:{IsPerDay:false},
        regex:'^\\d{1,5}(\\.\\d{1,2})?$', 
        errorMessage:'TA must be greater than equal to 0 and less than 100000',
      },
      "ESI":{
        regex:'^\\d{1,3}(\\.\\d{1,2})?$', 
        errorMessage:'ESI must be less than 1000',
        filters:{IsPerDay:false,ConfigIDStatus:false}
      },
      "PF":{
        regex:'^\\d{1,3}(\\.\\d{1,2})?$', 
        errorMessage:'EPF must be less than 1000',
        filters:{IsPerDay:false,ConfigIDStatus:false}
      },
      "PaidLeave":{
        regex:'^(30|[0-2]?\\d)$', 
        errorMessage:'Paid leave must be less than equal to 30',
        filters:{IsPerDay:false}
      },
      "FixedIncentive":{
        regex:'^\\d{1,8}(\\.\\d{1,2})?$', 
        errorMessage:'Gross must be greater than 0 less than 100000000',
        filters:{IsPerDay:false}
      },
      "Securitydeposit":{
        regex:'^\\d{1,8}(\\.\\d{1,2})?$', 
        errorMessage:'Security Deposit be greater than 0 less than 100000000',
        filters:{IsPerDay:false}
      },
      "SDmonthlydeduction":{
        regex:'^\\d{1,5}(\\.\\d{1,2})?$', 
        errorMessage:'SD Monthly Deduction be greater than 0 less than 100000',
        filters:{IsPerDay:false}
      },
      "SickLeave":{
        regex:'^(30|[0-2]?\\d)$', 
        errorMessage:'Sick leave must be less than equal to 30',
        filters:{IsPerDay:false}
      },
      "IsPerDay":{
        default:false,
        type:'Boolean',
        filters:{}
      },
      "TDS":{
        filters:{IsPerDay:false},
        regex:'^\\d{1,6}(\.\d{1,2})?$', 
        errorMessage:'TDS must be greater than equal to 0 and less than 1000000',
      },
      "Basic":{
        filters:{},
        // regex:'^\\d{1,6}(\.\d{1,2})?$', 
        regex:'^[1-9]\\d{0,5}(\\.\\d{1,2})?$', 
        errorMessage:'Basic salary must be greater than 0 and less than 1000000',
      },
      // "Gross":{
      //   filters:{}
      // },
    }
    // this.editableColumns = [
    //   "HRA",
    //   "TA",
    //   "DA",
    //   "MA",
    //   "leaveDeduction",
    //   "LoanDeduction",
    //   "AdvanceDeduction",
    //   "ShiftAmount",
    //   "BasicSalary",
    //   "Incentive",
    //   "ESI",
    //   "PF",
    //   "PT",
    // ]

  }

  ngOnInit(): void {
    this.AdminID = localStorage.getItem("AdminID");
    this.UserID = localStorage.getItem("UserID");
    this.OrgID = localStorage.getItem("OrgID");
    this.GetOrganization()
    this.GetBranches()
    this.getEmployeeList()
  }
  getEmployeeList(){
    const json:any = {
        ReportType:"leave",
        AdminID:this.AdminID
    }
    if (this.selectedBranch) {
      json["BranchID"] =  this.selectedBranch.map((br:any)=>{return br.Value})
     }
    if (this.SelectedDepartments) {
      json["DepartmentID"] =  this.tempdeparray.map((br:any)=>{ return br.id})
     }
  this._commonservice.ApiUsingPost("Portal/GetEmpListOnBranch",json).subscribe((data) => {
  this.EmployeeListFilter = data.List
  }
  ,(error) => {
  console.log(error);this.spinnerService.hide();
  });
  }

  onEmpSelect(item:any){

  }
  onEmpDeSelect(item:any){

  }


  ngAfterViewInit(){

  }

downloadSample(){
  if(this.SelectedEmployees.length == 0){
    this.ShowToast("Please Select Employee","warning")
  }else{
    let employees = this.SelectedEmployees.map(res=>res.ID) || []
    let json = {
      EmpIDs : employees  
    }
    this._commonservice.ApiUsingPostNew("api/Account/DownloadExcelIncentive", json, { responseType: 'blob' })
    .subscribe((res: Blob) => {
      const blob = new Blob([res], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'EmployeeIncentiveTemplate.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    });
  }
}
onFileChange(event: any): void {
  const file = event.target.files[0];
  if (file) {
    this.selectedFile = file;
  }
}
uploadExcel(): void {
  if (!this.selectedFile) {
    // this.globalToastService.info('Please select a file first')
    this.ShowToast("Please select a file first","warning")
    return;
  }
  const formData = new FormData();
  formData.append('file', this.selectedFile, this.selectedFile.name);    
  const apiUrl = 'Account/UploadExcelIncentive';
  this._commonservice.ApiUsingPost(apiUrl,formData).subscribe(data =>{
    console.log(data);
    if(data.Status == true){
      this.ShowToast(data.Message,"success")
      if(data.ErrorFilePath){
        window.open(environment.Url+data.ErrorFilePath,'_blank')
      }
    }
    else if(data.Status == false){
      this.ShowToast(data.Message,"error")
    }else{
      this.ShowToast("An Error Occurred","error")
    }
  },(error)=>{
    this.ShowToast(error.error.message,"error")
  })
 
}

  onselectedOrg(item:any){
    this.selectedBranch = []
    this.SelectedDepartments = []
    this.GetBranches()
  }
  onDeselectedOrg(item:any){
    this.selectedBranch = []
    this.SelectedDepartments = []
    this.GetBranches()
  }

  GetOrganization() {
    this.ApiURL = "Admin/GetSuborgList?OrgID="+this.OrgID+"&AdminId="+this.UserID
    this._commonservice.ApiUsingGetWithOneParam(this.ApiURL).subscribe((data) => {
      this.OrgList = data.List
      if(data.List.length == 1){
        this.selectedOrganization = [{Value:this.OrgList[0].Value,Text:this.OrgList[0].Text}]
        this.onselectedOrg({Value:this.OrgList[0].Value,Text:this.OrgList[0].Text})
      }
    }, (error) => {
      this.ShowToast(error,"error")
       console.log(error);
    });
  }

  GetBranches() {
    // let storedEmpBranch = localStorage.getItem("EditEmployeeBranch")
    this.selectedBranch=[];
    let suborgid = this.selectedOrganization.map(res => res.Value)[0] || 0
    this.ApiURL = "Admin/GetBranchListupdated?OrgID="+this.OrgID+"&SubOrgID="+suborgid+"&AdminId="+this.AdminID
     this._commonservice.ApiUsingGetWithOneParam(this.ApiURL).subscribe((data) => {
       this.BranchList = data.List
       this.GetDepartmentsList()
     }, (error) => {
      //  this.globalToastService.error(error);
      this.ShowToast(error.message,"error")
        console.log(error);
     });
   }

  onBranchtextSelect(item: any) {
    this.temparray = [];
    this.temparray.push({ id: item.Value, text: item.Text });
    this.GetDepartmentsList();
  }

  onBranchDeSelect(item:any){
    console.log(item,"item");
    this.temparray.splice(this.temparray.indexOf(item), 1);
    this.GetDepartmentsList();
    this.SelectedDepartments = []
    this.tempdeparray = []
  }
  
  onDeptSelect(item:any){
    console.log(item,"item");
    this.tempdeparray = []
    this.tempdeparray.push({id:item.Value, text:item.Text });
  }
  
  onDeptSelectAll(item:any){
    console.log(item,"item");
    this.tempdeparray = item;
  }

  onDeptDeSelectAll(){
   this.tempdeparray = [];
  }

  onDeptDeSelect(item:any){
   console.log(item,"item");
   this.tempdeparray.splice(this.tempdeparray.indexOf(item), 1);
  }

  GetDepartmentsList() {
    this.SelectedDepartments=[];
    var loggedinuserid=localStorage.getItem("UserID");
    let arr = this.temparray.length>0 ? this.temparray : this.BranchList
    const json = {
      OrgID:this.OrgID,
      AdminID:loggedinuserid,
      Branches: arr.map((br: any) => {
        return {
          id: br.id || br.Value,
        };
      }),
    } 

    this._commonservice.ApiUsingPost("Portal/GetEmployeeDepartments", json).subscribe(
      (data) => {
        if (data.DepartmentList.length > 0) {
          this.DepartmentList = data.List;
        }
        this.tempdeparray = this.tempdeparray?.filter((td:any)=>{
          let res = this.DepartmentList?.findIndex((dl:any)=>dl.id == td.id)
          return res>=0
        })
        this.SelectedDepartments = this.SelectedDepartments?.filter((td:any)=>{
          let res = this.DepartmentList?.findIndex((dl:any)=>dl.id == td.Value)
          return res>=0
        })
        
        console.log({DepartmentList:this.DepartmentList,tempdeparray:this.tempdeparray,SelectedDepartments:this.SelectedDepartments});
        
        // this.tempdeparray: {id: 1374, text: 'Traders'}
        // this.SelectedDepartments : [
        //   {
        //       "Value": 1374,
        //       "Text": "Traders"
        //   }
        // ]

      },
      (error) => {
        // this.globalToastService.error(error);
        this.ShowToast(error,"error")
        console.log(error);
      }
    );
  }

  GetEmployeeList()
  {
  
    this.spinnerService.show();
    this.employeeLoading = true
    let Branch = this.temparray.map((y:any) => y.id)[0] || 0
    let Dept = this.tempdeparray.map((y:any) => y.id)[0] || 0
    // api/Portal/GetSalaryConfigurations?AdminID=0&BranchID=0&DepartmentID=0
    this.ApiURL="Portal/GetEmployeeSalary?AdminID="+this.AdminID+"&BranchID="+Branch+"&DepartmentID="+Dept
      this._commonservice.ApiUsingGetWithOneParam(this.ApiURL).subscribe((res:any)  => {    
        this.spinnerService.hide();
        this.employeeLoading = false
        var table = $('#DataTables_Table_0').DataTable();
        table.destroy();
        this.EmployeeList = res.SalaryList.map((l:any,i:any)=>{return {
          SLno:i+1,
          ...l,
          ConfigIDStatus:l.ConfigID>0?true:false
        }})
        // console.log(this.EmployeeList);
        
        this.spinnerService.hide();
        this.employeeLoading = false
      }, (error) => {
        this.spinnerService.hide();
        this.employeeLoading = false
        // this.globalToastService.error(error.message);
        this.ShowToast(error.message,"error")
      })
  }

  downloadReport(){
    let selectedColumns = ["SLno","EmployeeID","FixedIncentive","Securitydeposit","SDmonthlydeduction","Gross","Basic","HRA","DA","ESI","PF","PaidLeave","SickLeave"]
    this.commonTableChild.downloadReport(selectedColumns)
  }


  updateEmployeSalary(empDetails:any){
    let Branch = this.temparray.map((y:any) => y.id)[0] || 0
    let Dept = this.tempdeparray.map((y:any) => y.id)[0] || 0
    //  AdminID="+this.AdminID+"&BranchID="+Branch+"&DepartmentID="+Dept
    this.ApiURL="Portal/UpdateEmployeeSalary"
    let data = {AdminID:this.AdminID,"SalaryDetails":empDetails.map((emp:any)=>{
      return {
        EmployeeID: emp.EmployeeID,
        HRA: emp.HRA ,
        DA: emp.DA ,
        TA: emp.TA ,
        MA: emp.MA ,
        ESI: emp.ESI ,
        PF: emp.PF ,
        FixedIncentive:emp.FixedIncentive,
        Securitydeposit:emp.Securitydeposit,
        SDmonthlydeduction:emp.SDmonthlydeduction,
        PaidLeave: emp.PaidLeave ,
        SickLeave: emp.SickLeave ,
        IsPerDay: emp.IsPerDay ,
        Basic: emp.Basic ,
        Gross: emp.Gross ,
      };
    })}

    
    this._commonservice.ApiUsingPost(this.ApiURL,data).subscribe((res:any)  => {    
      this.spinnerService.hide();
      // this.globalToastService.success(res.Message);
      this.ShowToast(res.Message,"success")
    }, (error) => {
      this.spinnerService.hide();
      // this.employeeLoading = false
      // this.globalToastService.error(error.m5essage);
      this.ShowToast(error.message,"error")
    });
  }

  
editColumn(row:any){
  let data = row.data
  let column = row.column
  let value = row.value
  console.log(this.EmployeeList);
  console.log(row);
  
  let index = this.EmployeeList.findIndex((e:any)=>e.EmployeeID == data.EmployeeID)
  console.log({index});
  
  if(!this.editableColumns[column].type)
  this.EmployeeList[index][column] = Number(value)

  if(this.editableColumns[column].type == 'Boolean')
  this.EmployeeList[index][column] = Boolean(value)
  
  if(column == 'IsPerDay'){
    if(value == true){
      this.EmployeeList[index]['salaryTemp'] = {
        PaidLeave:Number(this.EmployeeList[index]['PaidLeave']),
        SickLeave:Number(this.EmployeeList[index]['SickLeave']),
        FixedIncentive:Number(this.EmployeeList[index]['FixedIncentive']),
        Securitydeposit:Number(this.EmployeeList[index]['Securitydeposit']),
        SDmonthlydeduction:Number(this.EmployeeList[index]['SDmonthlydeduction']),
        ESI:Number(this.EmployeeList[index]['ESI']),
        PF:Number(this.EmployeeList[index]['PF']),
        PT:Number(this.EmployeeList[index]['PT']),
        TDS:Number(this.EmployeeList[index]['TDS']),
        Gross:Number(this.EmployeeList[index]['Gross']),
        Basic:Number(this.EmployeeList[index]['Basic']),
        HRA:Number(this.EmployeeList[index]['HRA']),
        DA:Number(this.EmployeeList[index]['DA']),
        MA:Number(this.EmployeeList[index]['MA']),
        TA:Number(this.EmployeeList[index]['TA'])
      }
      this.EmployeeList[index]['FixedIncentive'] = 0
      this.EmployeeList[index]['Securitydeposit'] = 0
      this.EmployeeList[index]['SDmonthlydeduction'] = 0
      this.EmployeeList[index]['PaidLeave'] = 0
      this.EmployeeList[index]['SickLeave'] = 0
      this.EmployeeList[index]['ESI'] = 0
      this.EmployeeList[index]['PF'] = 0
      this.EmployeeList[index]['PT'] = 0
      this.EmployeeList[index]['TDS'] = 0
      this.EmployeeList[index]['Gross'] =  Math.floor((this.EmployeeList[index]['Gross'] > 0 ? this.formatNumber(this.EmployeeList[index]['Gross']) : this.formatNumber(this.EmployeeList[index]['Basic']))/30)
      this.EmployeeList[index]['Basic'] = this.formatNumber(this.EmployeeList[index]['Gross'])
      this.EmployeeList[index]['HRA'] = 0
      this.EmployeeList[index]['DA'] = 0
      this.EmployeeList[index]['MA'] = 0
      this.EmployeeList[index]['TA'] = 0
    }
    else{
      // this.EmployeeList[index]['Gross'] = this.formatNumber(this.EmployeeList[index]['Gross'] * 30)
      // this.calculateSalary(index,true,true)
      this.EmployeeList[index]['FixedIncentive'] = Number(this.EmployeeList[index]['salaryTemp']['FixedIncentive'])
      this.EmployeeList[index]['Securitydeposit'] = Number(this.EmployeeList[index]['salaryTemp']['Securitydeposit'])
      this.EmployeeList[index]['SDmonthlydeduction'] = Number(this.EmployeeList[index]['salaryTemp']['SDmonthlydeduction'])
      this.EmployeeList[index]['PaidLeave'] = Number(this.EmployeeList[index]['salaryTemp']['PaidLeave'])
      this.EmployeeList[index]['SickLeave'] = Number(this.EmployeeList[index]['salaryTemp']['SickLeave'])
      this.EmployeeList[index]['ESI']       = Number(this.EmployeeList[index]['salaryTemp']['ESI'])
      this.EmployeeList[index]['PF']        = Number(this.EmployeeList[index]['salaryTemp']['PF'])
      this.EmployeeList[index]['PT']        = Number(this.EmployeeList[index]['salaryTemp']['PT'])
      this.EmployeeList[index]['TDS']       = Number(this.EmployeeList[index]['salaryTemp']['TDS'])
      this.EmployeeList[index]['Gross']     = Number(this.EmployeeList[index]['salaryTemp']['Gross'])
      this.EmployeeList[index]['Basic']     = Number(this.EmployeeList[index]['salaryTemp']['Basic'])
      this.EmployeeList[index]['HRA']       = Number(this.EmployeeList[index]['salaryTemp']['HRA'])
      this.EmployeeList[index]['DA']        = Number(this.EmployeeList[index]['salaryTemp']['DA'])
      this.EmployeeList[index]['MA']        = Number(this.EmployeeList[index]['salaryTemp']['MA'])
      this.EmployeeList[index]['TA']        = Number(this.EmployeeList[index]['salaryTemp']['TA'])
    }

  }
  
  if(!(this.EmployeeList[index]['IsPerDay'] == true)){
    if(['Gross'].includes(column)){
      this.calculateSalary(index,true,true)
    }else{
      this.calculateSalary(index,false,true)
    }
  }
    if(["Basic","HRA","DA","MA","TA",].includes(column)){
      this.EmployeeList[index]['Gross'] = this.EmployeeList[index]['Basic'] +this.EmployeeList[index]['HRA'] +this.EmployeeList[index]['DA'] +this.EmployeeList[index]['MA'] +this.EmployeeList[index]['TA']
    }

}

formatNumber(num: number) {
  return num % 1 === 0 ? num : parseFloat(num.toFixed(2));
}

calculate(type:string,SalaryFormulae:any,empList:any,){
  for (let i = 0; i < SalaryFormulae.length; i++) {
    const sf = SalaryFormulae[i];
    if(sf.SalaryType == type){
      let value =0
      if(sf.isBasic) value += empList.Basic
      if(sf.isHRA) value += empList.HRA
      if(sf.isDA) value += empList.DA
      if(sf.isTA) value += empList.TA
      if(sf.isMA) value += empList.MA

      value = this.formatNumber(Number(value))
      
      
      if((sf.Min == null || value >= sf.Min) && (sf.Max == null || value <= sf.Max)){
        
        console.log("--------------------------");
        console.log("--------------------------");
        console.log(sf);
        console.log("value : ", value);
        console.log(sf.Min ," - ", sf.Max);
        console.log(sf.Min == null,value >= sf.Mi,sf.Max == null,value <= sf.Max);
        
        console.log("--------------------------");
        console.log("--------------------------");
        if(sf.isAmount == true){
          return this.formatNumber(Number(sf.Value))
        }else{
          return this.formatNumber(Number(value * (sf.Value/100)))
}
}
    }
  }
  return 0
}


calculateSalary(index:any,total:boolean,deductions:boolean){
  if(this.EmployeeList[index].SalaryCalculation){
    console.log(this.EmployeeList[index]);
    let config = this.EmployeeList[index].SalaryCalculation.config
    let formula = this.EmployeeList[index].SalaryCalculation.formula
    if(total==true && config)
      {
        this.EmployeeList[index]['FixedIncentive']=0;
        this.EmployeeList[index]['Securitydeposit']=0;
        this.EmployeeList[index]['SDmonthlydeduction']=0;
      this.EmployeeList[index]['Basic'] = this.formatNumber(this.EmployeeList[index].Gross * (config.Basic / 100))
      if(config.isHRA){
        this.EmployeeList[index]['HRA'] = this.formatNumber(this.EmployeeList[index].Gross * (config.HRA / 100))
      } else this.EmployeeList[index]['HRA'] = 0
      if(config.isDA){
        this.EmployeeList[index]['DA'] = this.formatNumber(this.EmployeeList[index].Gross * (config.DA / 100))
      } else this.EmployeeList[index]['DA'] =  0
      if(config.isTA){
        this.EmployeeList[index]['TA'] = this.formatNumber(this.EmployeeList[index].Gross * (config.TA / 100))
      } else this.EmployeeList[index]['TA'] =  0
      if(config.isMA){
        this.EmployeeList[index]['MA'] = this.formatNumber(this.EmployeeList[index].Gross * (config.MA / 100))
      } else this.EmployeeList[index]['MA'] =  0
    }
    if(deductions==true && config){
      if(config.isESI){
        this.EmployeeList[index]['ESI'] = this.formatNumber(this.calculate('ESI',formula,this.EmployeeList[index]))
      } else this.EmployeeList[index]['ESI'] = 0
      if(config.isPF){
        this.EmployeeList[index]['PF'] = this.formatNumber(this.calculate('EPF',formula,this.EmployeeList[index]))
      } else this.EmployeeList[index]['PF'] =  0
    }

  }else{
    this.GetSalaryConfigs(this.EmployeeList,index,total,deductions)
  }
}



GetSalaryConfigs(empList:any,index:any,total:boolean,deductions:boolean) {
  let Branch = empList[index].BranchID || 0;
  let Dept = empList[index].DepartmentID || 0;
  if (Branch == 0 && Dept == 0) return;
  let json = {
    Employeelist: [],
    BranchList: Branch != 0 ? [Branch] : [],
    DepartmentList: Dept != 0 ? [Dept] : [],
  };

  if (
    json.Employeelist.length == 0 &&
    json.BranchList.length == 0 &&
    json.DepartmentList.length == 0
  ) {
    // this.globalToastService.warning(
    //   "Please select a Branch or a Department or an Employee"
    // )
    this.ShowToast( "Please select a Branch or a Department or an Employee","warning")
    return
}
  this.spinnerService.show();

  empList[index]['SalaryCalculation'] = {config:null,formula:null}
  this._commonservice
    .ApiUsingPost("SalaryCalculation/getSalaryConfiguration", json)
    .subscribe(
      (data) => {
        empList[index]['SalaryCalculation']['config'] = data?.List[0]?.Configfields[0];
        this._commonservice
          .ApiUsingPost("SalaryCalculation/GetSalaryCalculationConfig", json)
          .subscribe(
            (calData) => {
              console.log({ calData });
              empList[index]['SalaryCalculation']['formula'] = calData.List[0]?.ConfigFields
              this.spinnerService.hide();
              this.calculateSalary(index,total,deductions)
            },
            (error) => {
              this.spinnerService.hide();
              // this.globalToastService.error(error.message);
              this.ShowToast(error.message,"error")
            }
          );
      },
      (error) => {
        this.spinnerService.hide();
        // this.globalToastService.error(error.message);
        this.ShowToast(error.message,"error")
      }
    );
}
actionEmitter(data:any){
  // if(data.action.name == "Edit"){
  // }
  // else if(data.action.name == "View Details"){
  //   this.ViewDetails(data.row.ID);
  // }
  // else 
  if(data.action.name == 'editColumn'){
    this.editColumn(data.row)
  }
  else if(data.action.name == 'updatedSelectedRows'){
    this.selectedRows = data.row
  }
  else 
  if(data.action.name == 'Submit Salary Configuration'){
    this.updateEmployeSalary([data.row])
  }
  
}

SubmitBulkSalaryConfiguration(){
// // console.log(this.selectedRows);
// for (let i = 0; i < this.selectedRows.length; i++) {
//   const row = this.selectedRows[i];
//   // this.submitSummary(row)
// }
this.updateEmployeSalary(this.selectedRows)

}

  ShowToast(message: string, type: 'success' | 'warning' | 'error'): void {
    this.dialog.open(ShowalertComponent, {
      data: { message, type },
      panelClass: 'custom-dialog',
      disableClose: true  // Prevents closing on outside click
    }).afterClosed().subscribe((res) => {
      if (res) {
        console.log("Dialog closed");
      }
    });
  }


}
