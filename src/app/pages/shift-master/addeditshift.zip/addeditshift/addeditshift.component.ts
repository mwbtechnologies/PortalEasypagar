import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { HttpCommonService } from 'src/app/services/httpcommon.service';
export class FormInput {
  OrgID:any;
  ShiftName:any;
  FromTime:any;
  ToTime:any;
  Branches:any;
  Departments:any;
  MinWorkHours:any;
  Percentage:any;
}
@Component({
  selector: 'app-addeditshift',
  templateUrl: './addeditshift.component.html',
  styleUrls: ['./addeditshift.component.css']
})
export class AddeditshiftComponent {
  formInput: FormInput|any;
  public isSubmit: boolean;
  BranchList:any[]=[]
  ApiURL:any
  Branches:any
  selectedBranch:any;selectedDepartment:any;
  temparray:any=[]; tempdeparray:any=[];
  isEdit:boolean
  AdminID:any;OrgID:any;
  AmountType:any;
  branchSettings:IDropdownSettings = {};
  DepartmentList: any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private globalToastService: ToastrService, private _commonservice: HttpCommonService, private toastr: ToastrService,
  private spinnerService: NgxSpinnerService, public dialogRef: MatDialogRef<AddeditshiftComponent>){
    this.isSubmit = false
    this.isEdit = this.data.isEdit || false;
   

    this.formInput = {    
      Branches :this.data.row?.BranchName || '' ,
      Departments :this.data.row?.DepartmentName || '' ,
      OrgID:'',
      FromTime:this.data.row?.StartTime || '',
      ToTime:this.data.row?.EndTime || '',
      ShiftName : this.data.row?.ShiftName || '',
      GraceIn :this.data.row?.GraceInTime || 0,
      GraceOut :this.data.row?.GraceOutTime || 0,
      Amount:this.data.row?.Amount || '',
      IsPercent:this.isEdit && this.data.row?.IsPercent || false,
      isHalfDay :this.isEdit && this.data.row?.IsHalfDay || false,
      MinWorkHours:this.data.row?.MinWorkingHours || 0,

    };

    this.branchSettings = {
      singleSelection: false,
      idField: 'Value',
      textField: 'Text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 2,
      allowSearchFilter: true,
    };
    this.AmountType="Amount (Rs)";
    
  }
  ngOnInit(){
    this.OrgID = localStorage.getItem("OrgID");
    this.AdminID = localStorage.getItem("AdminID");
    this.ApiURL = "Admin/GetBranchList?OrgID=" + this.OrgID + "&AdminId=" + this.AdminID;
    this.GetBranches();
    this.GetDepartments();
  }
  changeamttype()
  {
    if(this.AmountType=="Amount (Rs)")
    {
this.AmountType="Ratio (%)";
    }
    else{
this.AmountType="Amount (Rs)";
    }
  }
  GetBranches() {
    this._commonservice.ApiUsingGetWithOneParam(this.ApiURL).subscribe((data) => {
      this.BranchList = data.List;
      console.log(this.BranchList, "branchlist");
    }, (error) => {
      this.globalToastService.error(error); console.log(error);
    });
 
  }
  GetDepartments() {
    this.selectedBranch =  this.temparray.map((br: any) => {
      return {
       "id": br.id,
       "text":br.text // Ensure this is the correct property
       };
      })
    const json={
      "Branches":this.selectedBranch
    }
    this._commonservice.ApiUsingPost("Portal/GetDepartments",json).subscribe((data) => {
      console.log(data);
      if (data.DepartmentList.length > 0) {
        this.DepartmentList = data.List;
      }
    }, (error) => {
      this.globalToastService.error(error); console.log(error);
    });
  }

  onDeptSelect(item:any){
    console.log(item,"item");
    this.tempdeparray.push({id:item.Value, text:item.Text });
   }
   onDeptDeSelect(item:any){
    console.log(item,"item");
    this.tempdeparray.splice(this.tempdeparray.indexOf(item), 1);
   }

  

  onBranchSelect(item:any){
   console.log(item,"item");
   this.temparray.push({id:item.Value, text:item.Text });
   this.GetDepartments();
  }
  onBranchDeSelect(item:any){
   console.log(item,"item");
   this.temparray.splice(this.temparray.indexOf(item), 1);
   this.GetDepartments();
  }

  CreateShift() {
   if(this.formInput.ShiftName == ""||this.formInput.ShiftName == undefined||this.formInput.ShiftName == null||this.formInput.ShiftName == 0) {
      this.globalToastService.warning("Please Enter Shift Title...!");
      return false;
    }
    else if(this.formInput.FromTime == ""||this.formInput.FromTime == undefined||this.formInput.FromTime == null||this.formInput.FromTime == 0) {
      this.globalToastService.warning("Please Select FromTime");
      return false;
    } 
    else if (this.formInput.ToTime == ""||this.formInput.ToTime == undefined||this.formInput.ToTime == null||this.formInput.ToTime == 0){
      this.globalToastService.warning("Please Select ToTime");
      return false;
    } 
      else{
      this.selectedBranch =  this.temparray.map((br: any) => {
        return {
         "id": br.id,
         "text":br.text // Ensure this is the correct property
         };
        })
        this.selectedDepartment =  this.tempdeparray.map((br: any) => {
          return {
           "id": br.id ,
           "text":br.text// Ensure this is the correct property
           };
          })
          if(this.formInput.Percentage>0){this.formInput.IsPercent=true;}else{this.formInput.IsPercent=false;}
        const json = {
          "AdminID":this.AdminID,
          "Branches":this.selectedBranch,
          "EndTime":this.formInput.ToTime,
          "StartTime":this.formInput.FromTime,
          "ShiftName":this.formInput.ShiftName,
          "Amount":this.formInput.Amount,
          "IsPercent":this.formInput.IsPercent,
          "GraceOutTime ":this.formInput.GraceOut,
          "GraceInTime ":this.formInput.GraceIn,
          "IsHalfDay":this.formInput.isHalfDay,
          "MinWorkingHours":this.formInput.MinWorkHours,
          "Departments":this.selectedDepartment
         }
         console.log(json,"json of add shift");
         
        this._commonservice.ApiUsingPost("Portal/CreateShift",json).subscribe(
    
          (data: any) => {
            if(data.Status==true){
            this.spinnerService.hide();
            this.globalToastService.success(data.Message);
            window.location.reload();
            }
            else
            {
              this.globalToastService.warning(data.Message);
                this.spinnerService.hide();
            }
            
          }, (error: any) => {
            sessionStorage.clear();
    
            this.globalToastService.error(error.message);
            this.spinnerService.hide();
           }
        );
        return true;
      }
        
    }
    UpdateShift() {
      if(this.formInput.Percentage>0){this.formInput.IsPercent=true;}else{this.formInput.IsPercent=false;}
        const json = {
          "ShiftID":this.data.row?.ShiftID,
          "ShiftName":this.data.row?.ShiftName,
          "StartTime":this.formInput.FromTime,
          "EndTime":this.formInput.ToTime,
          "Amount":this.formInput.Amount,
          "IsPercent":this.formInput.IsPercent,
          "GraceOutTime ":this.formInput.GraceOut,
          "GraceInTime ":this.formInput.GraceIn,
          "IsHalfDay":this.formInput.isHalfDay,
          "MinWorkingHours":this.formInput.MinWorkHours,
          "Departments":this.selectedDepartment
        }
         console.log(json,"json of add shift");
         
        this._commonservice.ApiUsingPost("Portal/UpdateShift",json).subscribe(
    
          (data: any) => {
            if(data.Status==true){
            this.spinnerService.hide();
            this.globalToastService.success(data.Message);
             this.dialogRef.close()
            }
            else
            {
              this.globalToastService.warning(data.Message);
                this.spinnerService.hide();
            }
            
          }, (error: any) => {
            sessionStorage.clear();
    
            this.globalToastService.error(error.message);
            this.spinnerService.hide();
           }
        );
        return true;
      }
        
    }
