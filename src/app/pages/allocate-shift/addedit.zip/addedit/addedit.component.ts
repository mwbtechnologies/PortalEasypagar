import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { HttpCommonService } from 'src/app/services/httpcommon.service';
// export class FormInput{
//   ShiftIDWeek1:any;  ShiftIDWeek2:any;  ShiftIDWeek3:any;  ShiftIDWeek4:any;  ShiftIDWeek5:any;  IsMondayWorkingW1:any;  IsMondayWorkingW2:any;  IsMondayWorkingW3:any;  IsMondayWorkingW4:any;  IsMondayWorkingW5:any;
//   IsTueWorkingW1:any;  IsTueWorkingW2:any;  IsTueWorkingW3:any;  IsTueWorkingW4:any;  IsTueWorkingW5:any;
//   IsWedWorkingW1:any;  IsWedWorkingW2:any;  IsWedWorkingW3:any;  IsWedWorkingW4:any; IsWedWorkingW5:any;
//   IsThuWorkingW1:any;  IsThuWorkingW2:any;  IsThuWorkingW3:any;  IsThuWorkingW4:any; IsThuWorkingW5:any;
//   IsFriWorkingW1:any;  IsFriWorkingW2:any;  IsFriWorkingW3:any;  IsFriWorkingW4:any; IsFriWorkingW5:any;
//   IsSatWorkingW1:any;  IsSatWorkingW2:any;  IsSatWorkingW3:any;  IsSatWorkingW4:any; IsSatWorkingW5:any;
//   IsSunWorkingW1:any;  IsSunWorkingW2:any;  IsSunWorkingW3:any;  IsSunWorkingW4:any; IsSunWorkingW5:any;
//   IsMondayWeekOffW1:any;  IsMondayWeekOffW2:any;  IsMondayWeekOffW3:any;  IsMondayWeekOffW4:any;  IsMondayWeekOffW5:any;
//   IsTueWeekOffW1:any;  IsTueWeekOffW2:any;  IsTueWeekOffW3:any;  IsTueWeekOffW4:any;  IsTueWeekOffW5:any;
//   IsWedWeekOffW1:any;  IsWedWeekOffW2:any;  IsWedWeekOffW3:any;  IsWedWeekOffW4:any; IsWedWeekOffW5:any;
//   IsThuWeekOffW1:any;  IsThuWeekOffW2:any;  IsThuWeekOffW3:any;  IsThuWeekOffW4:any; IsThuWeekOffW5:any;
//   IsFriWeekOffW1:any;  IsFriWeekOffW2:any;  IsFriWeekOffW3:any;  IsFriWeekOffW4:any; IsFriWeekOffW5:any;
//   IsSatWeekOffW1:any;  IsSatWeekOffW2:any;  IsSatWeekOffW3:any;  IsSatWeekOffW4:any; IsSatWeekOffW5:any;
//   IsSunWeekOffW1:any;  IsSunWeekOffW2:any;  IsSunWeekOffW3:any;  IsSunWeekOffW4:any; IsSunWeekOffW5:any;


// }
export class DynamicArrayPattern
{
WeekName:any;
WeekOffDays:any=Array<textvalue>;
WorkingDays:any=Array<textvalue>;
ShiftID:any;
ID:any;
}

export class WeekOff{
  IsMondayWeekOff:any;
  IsTuesdayWeekOff:any;
  IsWednesdayWeekOff:any;
  IsThursdayWeekOff:any;
  IsFridayWeekOff:any;
  IsSaturdayWeekOff:any;
  IsSundayWeekOff:any;
}
export class textvalue{
  text:any;
  value:any;
  id:any;
}

@Component({
  selector: 'app-addedit',
  templateUrl: './addedit.component.html',
  styleUrls: ['./addedit.component.css']
})
export class AddeditComponent {
  OrgID: any;
  // formInput: FormInput|any;
  AdminID: any;
  BranchApiURL: any
  shiftID:any;
  DynamicArray:Array<DynamicArrayPattern>=[];
  WeekOffDays:Array<textvalue>=[];
WorkingDays:Array<textvalue>=[];
  DepartmentApiURL: any
  BranchList: any[] = []
  ShiftList: any[] = []
  EmployeeList: any[] = []
  DepartmentList: any[] = []
  branches: any[] = []
  startTime: any
  endTime: any
  selectedBranch: any
  selectedDepartment: any
  selectedEmployee: any
  selectedDays: number[] = []
  selectedShift:any
  branchSettings: IDropdownSettings = {};
  departmentSettings: IDropdownSettings = {};
  shiftSettings: IDropdownSettings = {};
  employeeSettings: IDropdownSettings = {};
  isEdit: boolean
  NewApiURL:any
  BranchID:any
  isMonths:boolean = false
  Week1:boolean = false
  Week2:boolean = false
  Week3:boolean = false
  Week4:boolean = false
  Week5:boolean = false
  IsSunday:boolean = false
  IsMonday:boolean = false
  IsTuesday:boolean = false
  IsWednesday:boolean = false
  IsThursday:boolean = false
  IsFriday:boolean = false
  IsSaturday:boolean = false
  branch:any
  department:any
  Shift:any
  EmployeeName:any
  ShiftID:any;institutionsList:any;
  EmployeelistApiURL:any
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private globalToastService: ToastrService, private _commonservice: HttpCommonService, private toastr: ToastrService,
    private spinnerService: NgxSpinnerService, public dialogRef: MatDialogRef<AddeditComponent>
  ) {
    this.isEdit = this.data.isEdit || false;
    this.branch = this.data.row?.branch.Name || '';
    this.department = this.data.row?.department.Name || '';
    this.Shift = this.data.row?.ShiftName || '';
    this.EmployeeName = this.data.row?.EmpName || '';
    this.ShiftID = this.data.row?.ShiftID || '';
    this.IsSunday = this.data.row?.IsSunday || false
    this.IsMonday = this.data.row?.IsMonday || false
    this.IsTuesday = this.data.row?.IsTuesday || false
    this.IsWednesday = this.data.row?.IsWednesday || false
    this.IsThursday = this.data.row?.IsThursday || false
    this.IsFriday = this.data.row?.IsFriday || false
    this.IsSaturday = this.data.row?.IsSaturday || false
    this.Week1 = this.data.row?.IsWeek1 || false
    this.Week2 = this.data.row?.IsWeek2 || false
    this.Week3 = this.data.row?.IsWeek3 || false
    this.Week4 = this.data.row?.IsWeek4 || false
    this.Week5 = this.data.row?.IsWeek5 || false
   

    this.branchSettings = {
      singleSelection: true,
      idField: 'Value',
      textField: 'Text',
      itemsShowLimit: 2,
      allowSearchFilter: true,
    };
    this.departmentSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'text',
      itemsShowLimit: 2,
      allowSearchFilter: true,
    };
    this.shiftSettings = {
      singleSelection: true,
      idField: 'ID',
      textField: 'Name',
      itemsShowLimit: 2,
      allowSearchFilter: true,
    };
    this.employeeSettings = {
      singleSelection: false,
      idField: 'ID',
      textField: 'Name',
      itemsShowLimit: 2,
      allowSearchFilter: true,
    };

  }
  ngOnInit() {
    this.OrgID = localStorage.getItem("OrgID");
    this.AdminID = localStorage.getItem("AdminID");
    this.BranchApiURL = "Admin/GetBranchList?OrgID=" + this.OrgID + "&AdminId=" + this.AdminID;
    this.DepartmentApiURL = "Portal/GetDepartments"
    console.log(this.BranchApiURL, "url");

    this.NewApiURL="Portal/GetShiftbyBranch";
    this.EmployeelistApiURL="Portal/GetEmpListOnBranch";
    this.GetBranches()
    this.GetEmployeeList()
    this.GetShiftList()
    this.updateIsMonths();
    this.getdynamicarray();
  //   this.formInput = { ShiftIDWeek1:0, ShiftIDWeek2:0,  ShiftIDWeek3:0,  ShiftIDWeek4:0,  ShiftIDWeek5:0,
  //     IsMondayWorkingW1:false,IsMondayWorkingW2:false,IsMondayWorkingW3:false,IsMondayWorkingW4:false,IsMondayWorkingW5:false,
  //     IsTueWorkingW1:false,IsTueWorkingW2:false,IsTueWorkingW3:false,IsTueWorkingW4:false,IsTueWorkingW5:false,
  //     IsWedWorkingW1:false,IsWedWorkingW2:false,IsWedWorkingW3:false,IsWedWorkingW4:false, IsWedWorkingW5:false,
  //     IsThuWorkingW1:false,IsThuWorkingW2:false,IsThuWorkingW3:false,IsThuWorkingW4:false, IsThuWorkingW5:false,
  //     IsFriWorkingW1:false,IsFriWorkingW2:false,IsFriWorkingW3:false,IsFriWorkingW4:false, IsFriWorkingW5:false,
  //     IsSatWorkingW1:false,IsSatWorkingW2:false,IsSatWorkingW3:false,IsSatWorkingW4:false, IsSatWorkingW5:false,
  //     IsSunWorkingW1:false,IsSunWorkingW2:false,IsSunWorkingW3:false,IsSunWorkingW4:false, IsSunWorkingW5:false,
  //     IsMondayWeekOffW1:false,IsMondayWeekOffW2:false,IsMondayWeekOffW3:false,IsMondayWeekOffW4:false,IsMondayWeekOffW5:false,
  //     IsTueWeekOffW1:false,IsTueWeekOffW2:false,IsTueWeekOffW3:false,IsTueWeekOffW4:false,IsTueWeekOffW5:false,
  //     IsWedWeekOffW1:false,IsWedWeekOffW2:false,IsWedWeekOffW3:false,IsWedWeekOffW4:false, IsWedWeekOffW5:false,
  //     IsThuWeekOffW1:false,IsThuWeekOffW2:false,IsThuWeekOffW3:false,IsThuWeekOffW4:false, IsThuWeekOffW5:false,
  //     IsFriWeekOffW1:false,IsFriWeekOffW2:false,IsFriWeekOffW3:false,IsFriWeekOffW4:false, IsFriWeekOffW5:false,
  //     IsSatWeekOffW1:false,IsSatWeekOffW2:false,IsSatWeekOffW3:false,IsSatWeekOffW4:false, IsSatWeekOffW5:false,
  //     IsSunWeekOffW1:false,IsSunWeekOffW2:false,IsSunWeekOffW3:false,IsSunWeekOffW4:false, IsSunWeekOffW5:false};
  // }
  }
  updateIsMonths(){
    this.isMonths = this.Week1 || this.Week2 || this.Week3 || this.Week4 || this.Week5;
  }

  getdynamicarray()
  {
    let weektext=new textvalue();weektext.text="S";weektext.value=false;this.WeekOffDays.push(weektext);
    weektext=new textvalue();weektext.text="M";weektext.value=false;this.WeekOffDays.push(weektext);
    weektext=new textvalue();weektext.text="T";weektext.value=false;this.WeekOffDays.push(weektext);
    weektext=new textvalue();weektext.text="W";weektext.value=false;this.WeekOffDays.push(weektext);
    weektext=new textvalue();weektext.text="T";weektext.value=false;this.WeekOffDays.push(weektext)
    weektext=new textvalue();weektext.text="F";weektext.value=false;this.WeekOffDays.push(weektext);
    weektext=new textvalue();weektext.text="S";weektext.value=false;this.WeekOffDays.push(weektext);

    let working=new textvalue();working.text="S",working.value=false;this.WorkingDays.push(working);
    working=new textvalue();working.text="M",working.value=false;this.WorkingDays.push(working)
    working=new textvalue();working.text="T",working.value=false;this.WorkingDays.push(working);
    working=new textvalue();working.text="W",working.value=false;this.WorkingDays.push(working);
    working=new textvalue();working.text="T",working.value=false;this.WorkingDays.push(working);
    working=new textvalue();working.text="F",working.value=false;this.WorkingDays.push(working);
    working=new textvalue();working.text="S",working.value=false;this.WorkingDays.push(working);
   


    let arr = new DynamicArrayPattern();
    arr.ShiftID = 0;
    arr.ID=1;
    arr.WeekName = "Week-I";
    arr.WeekOffDays=this.WeekOffDays;
    arr.WorkingDays=this.WorkingDays;    
    this.DynamicArray.push(arr);

    arr = new DynamicArrayPattern();
    arr.ShiftID = 0;
    arr.ID=2;
    arr.WeekName = "Week-II";
    arr.WeekOffDays=this.WeekOffDays;
    arr.WorkingDays=this.WorkingDays;    
    this.DynamicArray.push(arr);

    arr = new DynamicArrayPattern();
    arr.ShiftID = 0;
    arr.ID=3;
    arr.WeekName = "Week-III";
    arr.WeekOffDays=this.WeekOffDays;
    arr.WorkingDays=this.WorkingDays;    
    this.DynamicArray.push(arr);

    arr = new DynamicArrayPattern();
    arr.ShiftID = 0;
    arr.ID=4;
    arr.WeekName = "Week-IV";
    arr.WeekOffDays=this.WeekOffDays;
    arr.WorkingDays=this.WorkingDays;    
    this.DynamicArray.push(arr);

    arr = new DynamicArrayPattern();
    arr.ShiftID = 0;
    arr.ID=5;
    arr.WeekName = "Week-V";
    arr.WeekOffDays=this.WeekOffDays;
    arr.WorkingDays=this.WorkingDays;    
    this.DynamicArray.push(arr);
    console.log(this.DynamicArray, "Dynamic Array")
    

  }
  GetEmployeeList(){
    const json:any = {
        }
        if (this.selectedBranch) {
          json["BranchID"] =  this.selectedBranch.map((br:any)=>{return br.Value})
         }
        if (this.selectedDepartment) {
          json["DepartmentID"] =  this.selectedDepartment.map((br:any)=>{ return br.id})
         }
    this._commonservice.ApiUsingPost(this.EmployeelistApiURL,json).subscribe((data) => {
      this.EmployeeList = data.List
    }
      ,(error) => {
      console.log(error);this.spinnerService.hide();
   });
  }

  GetShiftList(){
    const json:any = {
      "DepartmentID":[],
      "AdminId":this.AdminID
      }
      if (this.selectedBranch) {
       json["BranchID"] =  this.selectedBranch.map((br:any)=>{return  br.Value})
      }
      // if (this.selectedDepartment) {
      //  json["DepartmentID"] =  this.selectedDepartment.map((br:any)=>{return br.id})
      // }
      
    this._commonservice.ApiUsingPost(this.NewApiURL,json).subscribe((data) => {
      this.ShiftList = data.List
    },
     (error) => {
      this.globalToastService.error(error); console.log(error);
      
    });
  }

  GetBranches() {
    const selectedBranchId = this.data.row?.BranchId;
    this._commonservice.ApiUsingGetWithOneParam(this.BranchApiURL).subscribe((data) => {
      this.BranchList = data.List;
      if (selectedBranchId) {
        this.selectedBranch = this.BranchList.filter(branch => branch.Value === selectedBranchId);
      }
    }, (error) => {
      this.globalToastService.error(error); console.log(error);
    });
 
  }
  GetDepartments() {
    const json = { 
      "Branches": this.selectedBranch.map((br:any)=>{
        return {
          "id": br.Value
        }
      })
      }
    this._commonservice.ApiUsingPost(this.DepartmentApiURL,json).subscribe((data) => {
      this.DepartmentList = data.DepartmentList;
    }, (error) => {
      this.globalToastService.error(error); console.log(error);
    });
  }
  onBranchSelect(item: any) {
    this.GetShiftList()
    this.GetDepartments()
    this.GetEmployeeList()
   
  }
  onBranchDeSelect(item: any) {
    this.GetDepartments()
    this.GetShiftList()
  }
  onDepartmentSelect(item: any) {
    this.GetEmployeeList()
  }
  onDeselectDepartment(item: any) {
    this.selectedDepartment = this.selectedDepartment.filter((dept: any) => dept.id !== item.id);
    this.GetEmployeeList()
  }
  onShiftSelect(item: any) {
    this.shiftID = item.ID
  }
  onEmployeeSelect(item: any) {
  }

  addAllocation() {
    const json = {
        "ShiftID": this.shiftID,
        "EmployeeID": this.selectedEmployee.map((ep:any)=>{ return ep.ID}),
        "status": true,
        "CreatedbyID": this.AdminID,
        "IsMonday": this.IsMonday,
        "IsTuesday": this.IsTuesday,
        "IsWednesday": this.IsWednesday,
        "IsThursday": this.IsThursday,
        "IsFriday": this.IsFriday,
        "IsSaturday": this.IsSaturday,
        "IsSunday": this.IsSunday,
        "IsWeek1": this.Week1,
        "IsWeek2": this.Week2,
        "IsWeek3": this.Week3,
        "IsWeek4": this.Week4,
        "IsWeek5": this.Week5
    }
    console.log(json,"check values going");
    
    this._commonservice.ApiUsingPost("Portal/SaveShiftEmpMap",json).subscribe(data => {
      this.toastr.success(data.Message);
      this.spinnerService.hide();
      this.dialogRef.close({...json});
      window.location.reload();
    })
  }
  updateAllocation() {
    const json = {
        "ShiftID": this.ShiftID,
        "EmployeeID": [this.data.row?.Empid],
        "status": true,
        "CreatedbyID": this.data.row?.CreatedbyID,
        "IsMonday": this.IsMonday,
        "IsTuesday": this.IsTuesday,
        "IsWednesday": this.IsWednesday,
        "IsThursday": this.IsThursday,
        "IsFriday": this.IsFriday,
        "IsSaturday": this.IsSaturday,
        "IsSunday": this.IsSunday,
        "IsWeek1": this.Week1,
        "IsWeek2": this.Week2,
        "IsWeek3": this.Week3,
        "IsWeek4": this.Week4,
        "IsWeek5": this.Week5
    }
    console.log(json,"check values going this is edit");
    
    this._commonservice.ApiUsingPost("Portal/SaveShiftEmpMap",json).subscribe(data => {
      this.toastr.success(data.Message);
      this.spinnerService.hide();
      this.dialogRef.close();
      window.location.reload();
    })
  }

}




