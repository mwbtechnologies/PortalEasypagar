import { Component, Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgxSpinnerService } from 'ngx-spinner';
import { ShowalertComponent } from '../../create-employee/showalert/showalert.component';
import { HttpCommonService } from 'src/app/services/httpcommon.service';
import { parse } from 'date-fns';
@Component({
  selector: 'app-approvepayslip',
  templateUrl: './approvepayslip.component.html',
  styleUrls: ['./approvepayslip.component.css']
})
export class ApprovepayslipComponent {
  
    PaymentType:any[]=[ 
  { value: '1', label: 'CASH' },
  { value: '2', label: 'UPI' },
  { value: '3', label: 'CHEQUE' },
{ value: '4', label: 'PEPRO' }]
  PaymentSetting:IDropdownSettings={}
  selectedPayment:any;
  UserSelectedPayment:any[]=[];
  PaymentDate:any
 PaymentAmount:any
 Paymentcheque:any
PaymentBank:any
PaymentAccNo:any
PaymentIFSC:any
PaymentUPINO:any
PaymentUPIAPP:any
form: any;
AdminID:any
UserId:any
file:File | any;ImageUrl:any;ShowImage=false;
fileurl:any; 
ReferenceID:any
errorMessages : any = {};
selectedPayslips:any[]=[];
paysliparray:any[]=[];
netsalary:any;
  constructor(
    public dialogRef: MatDialogRef<ApprovepayslipComponent>,private dialog:MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,private spinnerService: NgxSpinnerService,private _commonservice:HttpCommonService
  ) {
    this.PaymentSetting = {
      singleSelection: true,
      idField: 'value',
      textField: 'label',
      itemsShowLimit: 1,
      allowSearchFilter: true,
    };
     
   
  }
  PaymentSelect(item:any){
this.selectedPayment=item.label;
  }
  PaymentDeselect(item:any){
this.selectedPayment=item.label;
  }

  ngOnInit(): void {
    const today = new Date();
    this.PaymentDate = today.toISOString().split('T')[0];
    this.AdminID = localStorage.getItem("AdminID");
    this.UserId = localStorage.getItem("UserID");
    console.log( this.data.IL,"il");
    this.selectedPayslips=this.data;
     this.selectedPayment = 'CASH';
       this.UserSelectedPayment = [{value:1,label:"CASH"}]
     this.netsalary=0;
     for(let i=0;i<this.selectedPayslips.length;i++)
    {
       
        this.netsalary=this.netsalary+parseFloat(this.selectedPayslips[i].NetSalary);
          
    }
  }

  UploadProof1Image1(event:any,form: NgForm) {
    const target = event.target as HTMLInputElement;
    this.file = (target.files as FileList)[0];
  
  var reader = new FileReader();
  reader.onload = (event: any) => {
  this, this.ImageUrl = event.target.result;
  this.fileurl=this.ImageUrl;
  }
  reader.readAsDataURL(this.file);
  this.ShowImage = true;
  const fData: FormData = new FormData();
  fData.append('formdata', JSON.stringify(form.value));
  fData.append('FileType', "Image");
  if (this.file != undefined) { fData.append('File', this.file, this.file.name);
  this._commonservice.ApiUsingPost("Admin/UploadFile?ImageType=Notification",fData).subscribe((data: { URL: any; }) => { this.ImageUrl=data.URL;});}
  }

  submitSummary(){
    if(!this.validate()) return
    this.spinnerService.show();
    let msg="";
    const paymentjson = {
      "AccountNumber":this.PaymentAccNo,
      "ChequeBankName":this.PaymentBank,
      "ChequeDate":this.PaymentDate,
      "ChequeNumber":this.Paymentcheque,
      "IFSCcode":this.PaymentIFSC,
      "ImageURL":this.ImageUrl,
      // "PaidAmount":this.TotalSalary,
      "PaidFromID":parseInt(this.AdminID),
      // "PaidToID":parseInt(this.selectedPayslips[i].EmployeeID),
      "PaymentDate":this.PaymentDate,
      "PaymentFor":"Salary",
      "PaymentID":"",
      "PaymentMode":this.selectedPayment[0],
      "PaymentTypeID":"",
      "ReferenceID":this.ReferenceID,
      "UPIBankName":this.PaymentUPIAPP,
      "UPINumber":this.PaymentUPINO
    }
    for(let i=0;i<this.selectedPayslips.length;i++)
    {
        var temp={
          "IsPayslipExist":false,
          "AdminAmount":this.selectedPayslips[i].AdminAmount,
          "BasicSalary":this.selectedPayslips[i].CalcBasicSalary,
          "HRA":this.selectedPayslips[i].CalcHRA,
          "DA":this.selectedPayslips[i].CalcDA,
          "TA":this.selectedPayslips[i].CalcTA,
          "MA":this.selectedPayslips[i].CalcMA,
          "ShiftAmount":this.selectedPayslips[i].ShiftAmount,
          "OTAmount":this.selectedPayslips[i].OTAmount,
          "Others":this.selectedPayslips[i].Others,
          "TotalOtherEarnings":this.selectedPayslips[i].Earningsothers,
          "Incentive":this.selectedPayslips[i].Incentive,
          "leaveDeduction":this.selectedPayslips[i].leaveDeduction,
          "LoanDeduction":this.selectedPayslips[i].LoanDeduction,
          "AdvanceDeduction":this.selectedPayslips[i].AdvanceDeduction,
          "Penalty":this.selectedPayslips[i].Penalty,
          "Deductionsothers":this.selectedPayslips[i].Deductionsothers,
          "ESI":this.selectedPayslips[i].CalcESI,
          "PF":this.selectedPayslips[i].CalcEPF,
          "ProfessionalTax":this.selectedPayslips[i].CalcPT,
          "TDS":this.selectedPayslips[i].TDS,
          "CalculatedLeaves":this.selectedPayslips[i].CalculatedLeaves,
          "Comment":this.ReferenceID,
          "DateWiseInfo":[],
          "Employee":this.selectedPayslips[i].Employee,
          "EmployeeID":this.selectedPayslips[i].EmployeeID,
          "EmployeeLeaves":this.selectedPayslips[i].EmployeeLeaves,
          "FromDate":this.selectedPayslips[i].FromDate,
          "Key":"en",
          "MonthID":this.selectedPayslips[i].MonthID,
          "Month":this.selectedPayslips[i].MonthID,
          "NetSalary":this.selectedPayslips[i].NetSalary,
          "NewLoanBalance":this.selectedPayslips[i].NewLoanBalance,
          "NewSalaryBalance":this.selectedPayslips[i].NewSalaryBalance,
          "OfficialHolidays":this.selectedPayslips[i].OfficialHolidays,
          "OldLoanBalance":this.selectedPayslips[i].OldLoanBalance,
          "OldSalaryBalance":this.selectedPayslips[i].OldSalaryBalance,
          "PaidAmount":this.selectedPayslips[i].PaidAmount,
          "PaidLeave":this.selectedPayslips[i].PaidLeave,
          "PayableSalary":this.selectedPayslips[i].PayableSalary,
            "PaymentID":0,
          "PayslipDate":this.selectedPayslips[i].PayslipDate,
          "PerDaySalary":this.selectedPayslips[i].PerDaySalary,
          "PresentDays":this.selectedPayslips[i].NoOfPresentDays,
          // "ProfessionalTax":this.selectedPayslips[i].ProfessionalTax,
          "SickLeave":this.selectedPayslips[i].SickLeave,
          "ToDate":this.selectedPayslips[i].ToDate,
          "TotalDays":this.selectedPayslips[i].TotalDays,
          "TotalLoanDeduction":this.selectedPayslips[i].TotalLoanDeduction,
          "TotalWokingDays":this.selectedPayslips[i].TotalWokingDays,
          "Type":'Pay',
          "WeekOffDays":this.selectedPayslips[i].WeekOffDays,
          "WeekOffDeduction":this.selectedPayslips[i].WeekOffDeduction,
          "Year":this.selectedPayslips[i].Year,
          "Bonus":this.selectedPayslips[i].Bonus,
          "Deduction":this.selectedPayslips[i].Deduction,
          "bonusdata":this.selectedPayslips[i].bonusdata,
          "Gross":this.selectedPayslips[i].Gross,
          "FinalGross":this.selectedPayslips[i].CalcGross,
          "LoanList":this.selectedPayslips[i].LoanList,
          "FixedIncentive":this.selectedPayslips[i].FixedIncentive,
          "SecurityDeposit":this.selectedPayslips[i].SecurityDeposit,
          "PT":this.selectedPayslips[i].CalcPT,
    }
    this.paysliparray.push(temp);
  }
var AdminID=localStorage.getItem("AdminID");
    const json={
      PaymentJson:paymentjson,
      Payslips:this.paysliparray,
      AdminID:AdminID
    }
    this._commonservice.ApiUsingPost("Payslip/BulkPayslipApprove",json).subscribe((data: any) => {
      if(data.Status==true){  
        msg=data.Message;
     }
      else
      {
     msg=data.Message;
        this.ShowToast(data.Message,"warning")
          this.spinnerService.hide();
      }
     }, (error: any) => {
       msg=error.Message;
      this.ShowToast(error.Message,"error")
      this.spinnerService.hide();
     }
  );
 this.dialogRef.close({msg});
this.spinnerService.hide();
  }
  Payslipdetails(){
}

cancelSummary(){
  this.dialogRef.close()
}

validate():boolean{
  this.errorMessages = {}
  let status = true
  if(this.selectedPayment == 'CHEQUE'){
    if(!this.Paymentcheque || this.Paymentcheque.length<=0){
      this.errorMessages['chequeno'] = {message:"Please enter a valid Cheque Number"}
      status = false
    }
    if(!this.PaymentBank || this.PaymentBank.length<=0){
      this.errorMessages['bankname'] = {message:"Please enter Bank Name"}
      status = false
    }
    if(!this.PaymentAccNo || this.PaymentAccNo.length<=0){
      this.errorMessages['accno'] = {message:"Please enter Account Number"}
      status = false
    }
    if(!this.PaymentIFSC || this.PaymentIFSC.length<=0){
      this.errorMessages['ifsccode'] = {message:"Please enter a valid IFSC Code"}
      status = false
    }else{
      let ifscPattern = /^[A-Z]{4}0[A-Z0-9]{6}$/;
      let ifscStatus =  ifscPattern.test(this.PaymentIFSC);
      if(!ifscStatus){
        this.errorMessages['ifsccode'] = {message:"Please enter a valid IFSC Code"}
        status = false
      }
    }
  }
  if(this.selectedPayment == 'UPI'){
    if(!this.PaymentUPINO || this.PaymentUPINO.length<=0){
      this.errorMessages['upino'] = {message:"Please enter a valid UPI Number"}
      status = false
    }
  }
  
  return status

}
ShowToast(message: string, type: 'success' | 'warning' | 'error'): void {
  this.dialog.open(ShowalertComponent, {
    data: { message, type },
    panelClass: 'custom-dialog',
    disableClose: true  // Prevents closing on outside click
  }).afterClosed().subscribe((res) => {
    if (res) {
      console.log("Dialog closed");
    }
  });
}



}