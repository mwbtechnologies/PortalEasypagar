export const series = {
    monthDataSeries1: {
      
      prices: [
        50,
        80,
        60,
       100
        
      ],
      dates: [
       "Jan",
       "Feb",
       "March",
       "April"
      ]
    },
    GraphValues : {
        
      prices: [
       50,
        80,
        60,
       100
        
      ],
      dates: [
       "Jan",
       "Feb",
       "March",
       "April"
      ]
    }
  
  };
  //bar graph
export const dataSeries = [
    [
    
    ]
  ];
  declare var module: NodeModule;
interface NodeModule {
  id: string;
}

  