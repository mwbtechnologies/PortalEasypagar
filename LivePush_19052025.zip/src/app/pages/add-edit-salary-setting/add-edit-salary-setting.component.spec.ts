import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditSalarySettingComponent } from './add-edit-salary-setting.component';

describe('AddEditSalarySettingComponent', () => {
  let component: AddEditSalarySettingComponent;
  let fixture: ComponentFixture<AddEditSalarySettingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditSalarySettingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditSalarySettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
