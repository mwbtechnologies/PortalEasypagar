import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppUpdatesRoutingModule } from './app-updates-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AppUpdatesRoutingModule
  ]
})
export class AppUpdatesModule { }
