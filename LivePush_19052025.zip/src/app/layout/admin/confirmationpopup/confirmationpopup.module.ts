import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmationpopupComponent } from './confirmationpopup.component';


@NgModule({
  declarations: [ConfirmationpopupComponent],
  imports: [
    CommonModule
  ]
})
export class ConfirmationpopupModule { }
