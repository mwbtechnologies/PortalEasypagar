import { Component } from '@angular/core';

@Component({
  selector: 'app-page-header2',
  templateUrl: './page-header2.component.html',
  styleUrls: ['./page-header2.component.css']
})
export class PageHeader2Component {

}
