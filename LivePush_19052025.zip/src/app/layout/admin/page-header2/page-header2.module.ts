import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PageHeader2RoutingModule } from './page-header2-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PageHeader2RoutingModule
  ]
})
export class PageHeader2Module { }
