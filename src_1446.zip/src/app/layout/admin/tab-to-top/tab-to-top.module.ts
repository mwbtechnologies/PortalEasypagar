import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TabToTopRoutingModule } from './tab-to-top-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TabToTopRoutingModule
  ]
})
export class TabToTopModule { }
