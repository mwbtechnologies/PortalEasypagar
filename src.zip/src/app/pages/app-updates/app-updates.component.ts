import { Component } from '@angular/core';

@Component({
  selector: 'app-app-updates',
  templateUrl: './app-updates.component.html',
  styleUrls: ['./app-updates.component.css']
})
export class AppUpdatesComponent {

}
