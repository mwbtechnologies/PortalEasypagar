import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApproveExpenseRoutingModule } from './approve-expense-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ApproveExpenseRoutingModule
  ]
})
export class ApproveExpenseModule { }
