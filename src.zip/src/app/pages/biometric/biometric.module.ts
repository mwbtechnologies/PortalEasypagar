import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BiometricRoutingModule } from './biometric-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BiometricRoutingModule
  ]
})
export class BiometricModule { }
