import { Component } from '@angular/core';

@Component({
  selector: 'app-tab-to-top',
  templateUrl: './tab-to-top.component.html',
  styleUrls: ['./tab-to-top.component.css']
})
export class TabToTopComponent {

}
