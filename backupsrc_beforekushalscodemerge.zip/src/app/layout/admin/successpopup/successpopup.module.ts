import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SuccesspopupComponent } from './successpopup.component';


@NgModule({
  declarations: [SuccesspopupComponent],
  imports: [
    CommonModule,
  ]
})
export class SuccesspopupModule { }
