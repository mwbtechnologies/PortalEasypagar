import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SwitcherRoutingModule } from './switcher-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SwitcherRoutingModule
  ]
})
export class SwitcherModule { }
