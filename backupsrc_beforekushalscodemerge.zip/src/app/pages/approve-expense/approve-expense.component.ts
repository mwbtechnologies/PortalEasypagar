import { Component } from '@angular/core';

@Component({
  selector: 'app-approve-expense',
  templateUrl: './approve-expense.component.html',
  styleUrls: ['./approve-expense.component.css']
})
export class ApproveExpenseComponent {

}
